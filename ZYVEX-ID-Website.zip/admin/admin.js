import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from "../config.js";
const supabase=createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY);
const $=id=>document.getElementById(id);
const rupiah=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n||0));
let currentUser=null, rows=[];
const fields=["title","rank","level","skins","price","image_url","description","contact_whatsapp","status","dp_amount"];
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
$("dp_enabled").addEventListener("change",()=> $("dp-wrap").classList.toggle("hidden",!$("dp_enabled").checked));
$("login-form").addEventListener("submit",async e=>{e.preventDefault();$("login-message").textContent="Memeriksa akun...";const {error}=await supabase.auth.signInWithPassword({email:$("email").value,password:$("password").value});if(error){$("login-message").textContent=error.message;return;}await checkSession();});
$("logout").addEventListener("click",async()=>{await supabase.auth.signOut();currentUser=null;showLogin();});
function showLogin(){$("login-view").classList.remove("hidden");$("dashboard").classList.add("hidden");}
function showDashboard(){$("login-view").classList.add("hidden");$("dashboard").classList.remove("hidden");}
async function checkSession(){const {data:{user}}=await supabase.auth.getUser();if(!user){showLogin();return;}const {data,error}=await supabase.from("admin_users").select("user_id").eq("user_id",user.id).maybeSingle();if(error||!data){await supabase.auth.signOut();$("login-message").textContent="Akun ini belum terdaftar sebagai admin. Tambahkan UUID akun ke tabel admin_users melalui SQL Editor.";showLogin();return;}currentUser=user;showDashboard();await loadRows();}
supabase.auth.onAuthStateChange(()=>{});
function resetForm(){$("account-form").reset();$("account-id").value="";$("level").value=1;$("skins").value=0;$("dp_amount").value=0;$("status").value="available";$("dp-wrap").classList.add("hidden");$("form-title").textContent="Tambah akun baru";$("save-button").textContent="Simpan akun";}
$("reset-form").addEventListener("click",resetForm);
$("account-form").addEventListener("submit",async e=>{
 e.preventDefault();if(!currentUser)return;
 const payload={};for(const f of fields){let v=$(f).value;payload[f]=["level","skins","price","dp_amount"].includes(f)?Number(v||0):v.trim();}
 payload.dp_enabled=$("dp_enabled").checked;
 if(!payload.dp_enabled)payload.dp_amount=0;
 $("save-button").disabled=true;$("form-message").textContent="Menyimpan...";
 const id=$("account-id").value;
 const result=id?await supabase.from("accounts").update(payload).eq("id",id):await supabase.from("accounts").insert(payload);
 $("save-button").disabled=false;
 if(result.error){$("form-message").textContent="Gagal: "+result.error.message;return;}
 $("form-message").textContent=id?"Perubahan akun tersimpan.":"Akun berhasil ditambahkan.";
 resetForm();await loadRows();
});
async function loadRows(){
 $("accounts-list").textContent="Memuat daftar...";
 const {data,error}=await supabase.from("accounts").select("*").order("created_at",{ascending:false});
 if(error){$("accounts-list").textContent="Gagal memuat: "+error.message;return;}
 rows=data||[];
 $("accounts-list").innerHTML=rows.length?`<table><thead><tr><th>Kode / Nama</th><th>Rank</th><th>Harga</th><th>Status</th><th>Aksi</th></tr></thead><tbody>${rows.map(a=>`<tr><td><b>${esc(a.account_code||"")}</b><br>${esc(a.title)}</td><td>${esc(a.rank||"-")}</td><td>${rupiah(a.price)}</td><td>${esc(a.status)}</td><td><div class="actions"><button class="secondary" data-edit="${a.id}">Edit</button><button class="danger" data-delete="${a.id}">Hapus</button></div></td></tr>`).join("")}</tbody></table>`:'<div class="empty">Belum ada akun. Tambahkan akun melalui formulir di atas.</div>';
 document.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>editRow(rows.find(a=>a.id===b.dataset.edit))));
 document.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>deleteRow(b.dataset.delete)));
}
function editRow(a){if(!a)return;$("account-id").value=a.id;for(const f of fields)$(f).value=a[f]??"";$("dp_enabled").checked=!!a.dp_enabled;$("dp-wrap").classList.toggle("hidden",!a.dp_enabled);$("form-title").textContent="Edit akun";$("save-button").textContent="Simpan perubahan";window.scrollTo({top:0,behavior:"smooth"});}
async function deleteRow(id){const a=rows.find(x=>x.id===id);if(!a||!confirm(`Hapus listing "${a.title}"? Tindakan ini tidak bisa dibatalkan.`))return;const {error}=await supabase.from("accounts").delete().eq("id",id);if(error){alert("Gagal menghapus: "+error.message);return;}await loadRows();}
$("refresh").addEventListener("click",loadRows);
async function init(){const {data:{session}}=await supabase.auth.getSession();if(session)await checkSession();else showLogin();}
init();
